// C program for Ali Baba and the Forty Thieves problem
// http://forum.enjoysudoku.com/ali-baba-and-the-forty-thieves-t37980.html
// This is a modification of a Knights Tour program I found on the internet
// https://www.geeksforgeeks.org/the-knights-tour-problem-backtracking-1/
#include<stdio.h>
#define N 11

/* A function to check if cell at x,y is safe to jump to */
int isSafe( int x, int y, int grid[N][N])
{
   return ( ( x >= 0 && x < N) && ( y >= 0 && y < N) && grid[x][y] == 0 );
}

/* A function to print solution matrix grid[N][N] */
void printEnchantedCourtyard( int grid[N][N])
{
   for (int x = 0; x < N; x++ )
   {
      printf( "\n");
      for (int y = 0; y < N; y++ )
      {
         if ( grid[x][y] == -1 ) { printf( " X  "); }
         if ( grid[x][y] ==  0 ) { printf( " .  "); }
         if ( grid[x][y] > 0 && grid[x][y] < 10 ) { printf( " %d  ", grid[x][y]); }
         if ( grid[x][y] > 9 )                    { printf( " %d ", grid[x][y]); }
      }
      printf( "\n");
   }
   printf( "\n");
}

/* A function to print route from start jump to end jump */
void printRoute( int start, int end, int grid[N][N])
{
   int routed = 0;
   for (int i=start; i<=end; i++ )
   {
      int r = -1, c = -1;
      for (int x = 0; x < N; x++ )        // scans the whole grid for each step!!!
      {
         for (int y = 0; y < N; y++ )
         {
            if ( grid[x][y] == i ) { r = x; c = y; }
         }
      }
      if ( r >= 0 && c >= 0 )
      {
         if ( i != start ) { printf( " - "); }
         printf( "(%d)r%dc%d", i, r+1, c+1);
         routed = 1;
      }
   }
   if ( routed == 1 ) { printf( "\n"); }
}

/* A recursive function to solve Ali Baba and the Forty Thieves problem    */
int findAliBabaRoute( int jump0,                   // starting cell
                      int x1, int y1, int jump1,   // start
                      int x2, int y2, int jump2,   // end
                      int grid[N][N], int xJump[N], int yJump[N])
{
   if ( jump1 < jump2 )
   {
      int next_jump = jump1 + 1;

      /* Try all next jumps from the current cell x, y */
      for (int i = 0; i < 8; i++ )
      {
         int next_x = x1 + xJump[i];
         int next_y = y1 + yJump[i];

         if ( next_x < 0  ) { next_x += 11; }   // wrap around
         if ( next_x > 10 ) { next_x -= 11; }
         if ( next_y < 0  ) { next_y += 11; }
         if ( next_y > 10 ) { next_y -= 11; }

         if ( isSafe( next_x, next_y, grid) )
         {
            grid[next_x][next_y] = next_jump;
            findAliBabaRoute( jump0, next_x, next_y, next_jump, x2, y2, jump2, grid, xJump, yJump);
            grid[next_x][next_y] = 0;   // backtracking
         }
         else
         if ( next_x == x2 && next_y == y2 && next_jump == jump2 )
         {
            printRoute( jump0, jump2, grid);
         }
      }
   }

   return 0;
}

/* This function solves the Ali Baba and the Forty Thieves problem using Backtracking.
This function mainly uses findAliBabaRoute() to solve the problem.
It returns false if no complete tour is possible, otherwise return true and prints the tour.
Please note that there may be more than one solutions, this function prints one of the feasible solutions. */
int helpAliBaba()
{
   int grid[N][N] = {
      { 30,  0,  0,  0, 24,  0,  0,  0,  0,  0,  0 },
      { -1, -1,  0, -1, -1,  0,  0, 40,  8,  0,  0 },
      { 31,  0,  0, -1, -1,  0, -1, -1,  0, -1, -1 },
      { -1, -1,  0,  0,  0,  0, -1, -1,  0,  0,  0 },
      {  0,  0, -1,  0, -1, 58, 18,  0,  0, -1, -1 },
      { 81,  0, -1, 44, -1,  0, -1,  0, -1,  0,  1 },
      {  0,  0, -1,  0, -1,  0,  0,  0, 17, -1, -1 },
      { -1, -1,  0,  0,  0,  0, -1, -1,  0,  0,  0 },
      {  0,  0, 37, -1, -1,  0, -1, -1,  0, -1, -1 },
      { -1, -1,  0, -1, -1, 70,  0,  0,  0, 79,  4 },
      {  0,  0,  0,  0,  0,  0,  0, 62,  0,  0, 52 }};

   /* pass 1 route solutions */

   /* (4)r10c11 - (5)r8c11 - (6)r6c2 - (7)r4c11 - (8)r2c9 */

// grid[ 8-1][11-1] =  5;
// grid[ 6-1][ 2-1] =  6;
// grid[ 4-1][11-1] =  7;

   /* (79)r10c10 - (80)r8c10 - (81)r6c1 */

// grid[ 8-1][10-1] = 80;

   /* pass 2 route solution */

   /* (1)r6c11 - (2)r8c9 - (3)r10c9 - (4)r10c11 */

// grid[ 8-1][ 9-1] =  2;
// grid[10-1][ 9-1] =  3;

   printf( "Start:\n");
   printEnchantedCourtyard( grid);

   /* xJump[] and yJump[] define next jump of Ali Baba.
   xJump[] is for next value of x coordinate
   yJump[] is for next value of y coordinate */
   int xJump[8] = { -2,  0,  2, -2,  2, -2,  0,  2 };
   int yJump[8] = { -2, -2, -2,  0,  0,  2,  2,  2 };

   findAliBabaRoute(  1,  5, 10,  1,  9, 10,  4, grid, xJump, yJump);   // pass 2
   printf( "\n");
   findAliBabaRoute(  4,  9, 10,  4,  1,  8,  8, grid, xJump, yJump);   // pass 1
   printf( "\n");
   findAliBabaRoute(  8,  1,  8,  8,  6,  8, 17, grid, xJump, yJump);
   printf( "\n");
// findAliBabaRoute( 17,  6,  8, 17,  4,  6, 18, grid, xJump, yJump);   // one jump only!
// printf( "\n");
   findAliBabaRoute( 18,  4,  6, 18,  0,  4, 24, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 24,  0,  4, 24,  0,  0, 30, grid, xJump, yJump);
   printf( "\n");
// findAliBabaRoute( 30,  0,  0, 30,  2,  0, 31, grid, xJump, yJump);   // one jump only!
// printf( "\n");
   findAliBabaRoute( 31,  2,  0, 31,  8,  2, 37, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 37,  8,  2, 37,  1,  7, 40, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 40,  1,  7, 40,  5,  3, 44, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 44,  5,  3, 44, 10, 10, 52, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 52, 10, 10, 52,  4,  5, 58, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 58,  4,  5, 58, 10,  7, 62, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 62, 10,  7, 62,  9,  5, 70, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 70,  9,  5, 70,  9,  9, 79, grid, xJump, yJump);
   printf( "\n");
   findAliBabaRoute( 79,  9,  9, 79,  5,  0, 81, grid, xJump, yJump);   // pass 1
   printf( "\n");

   return 1;
}

/* Driver program to test above functions */
int main( int argc, char *argv[])
{
   helpAliBaba();
   return 0;
}

