/* seclone.c
seclone.exe: sudoku explainer clone, singles only, solver, generator.
Copyright (C) 2018, 1to9only, <http://forum.enjoysudoku.com>.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
static char *FORMAT = "%g ED=%r/%p/%d";
static char *VERSION = "v=1.2.1.3.181117";

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <io.h>

#include "sud_constants.h"
#include "sud_defs.h"

int verbose = 0;                 // 1= solve (-s), 2= verbose (-v)

int grid [ Sudsize] = { 0, };    // sudoku grid, numbers=1-9, 0=empty
int clues[ Sudsize] = { 0, };    // bitwise clues, 0x0001=1, 0x0100=9, 0x01FF=full house

int placed = 0;                  // =1 if a number placement occurred

int rating = 0;
int pearl = 0;
int diamond = 0;

#include "sud_dump.c"
#include "sud_solve.c"
#include "sud_gen.c"

int main( int argc, char *argv[])
{
   char *puzzle = (char*)0;
   char buffer[ 100] = { 0, };

   for (int i=1; i<argc; i++ )
   {
      if ( argv[i][0] == '-' )
      {
         if ( argv[i][1] == 'g' && argv[i][2] == 0 )
         {
            generate();
            exit( 0);
         }
         else
         if ( argv[i][1] == 's' && argv[i][2] == 0 )
         {
            verbose = 1;
         }
         else
         if ( argv[i][1] == 'v' && argv[i][2] == 0 )
         {
            verbose = 2;
         }
      }
      else
      {
         if ( strlen( argv[i]) == 81 )          // is sudoku line
         {
            puzzle = argv[i];
         }
         else                                   // is sudoku file
         {
            struct _stat st = { 0, };
            int rc = 0, len = 0, f = 0;

            rc = _stat( argv[i], &st);
            len = st.st_size;
            if ( rc == 0 && len >= 81 )
            {
               f = _open( argv[i], _O_RDONLY|_O_BINARY);
               if ( f != -1 )
               {
                  rc = _read( f, buffer, 81);   // read 81 bytes only
                  rc = close( f);
                  buffer[ 81] = 0;              // null terminate after 81 chars
                  puzzle = buffer;
               }
            }
            else
            {
               printf( "file '%s' not found!\n", argv[i]);
               exit( 1);
            }
         }

      }
   }

   if ( puzzle != (char*)0 )
   {
      for (int c=0; c<Sudsize; c++ )
      {
         grid[ c] = 0;
         clues[ c] = AllBits;
      }
      for (int c=0; c<Sudsize; c++ )
      {
         int n = (int)puzzle[ c];      // clue
         n = (n<'1'||n>'9')?0:n-'0';   // digit
         if ( n != 0 )                 // given
         {
            grid[ c] = n;              // set grid
            clues[ c] = 0;             // clear clues
            for (int k=1; k<21; k++ )  // clear peers
            {
               clues[ peer[ c][ k]] &= ~mbits[ n];
            }
         }
      }

      if ( verbose > 0 ) {
      printf( "%s\n", puzzle);
      if ( verbose == 2 ) { dump_grid_clues(); }
      }

      solve();

      for (int i=0; i<Sudsize; i++ ) { int n = grid[ i]; printf( "%c", (n==0)?'.':'0'+n); } printf( "\n");

      printf( "ED=%d.%c/",   rating/10,  '0'+rating%10);
      printf(    "%d.%c/",    pearl/10,   '0'+pearl%10);
      printf(    "%d.%c\n", diamond/10, '0'+diamond%10);
   }
   else
   {
      printf( "nothing to do!\n\n");

      printf( "seclone.exe: sudoku explainer clone, singles only, solver, generator.\n");
      printf( "Copyright (C) 2018, 1to9only, <http://forum.enjoysudoku.com>.\n\n");

      printf( "This program is free software: you can redistribute it and/or modify\n");
      printf( "it under the terms of the GNU General Public License as published by\n");
      printf( "the Free Software Foundation, either version 3 of the License, or\n");
      printf( "(at your option) any later version.\n\n");

      printf( "This program is distributed in the hope that it will be useful,\n");
      printf( "but WITHOUT ANY WARRANTY; without even the implied warranty of\n");
      printf( "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n");
      printf( "GNU General Public License for more details.\n\n");

      printf( "You should have received a copy of the GNU General Public License\n");
      printf( "along with this program.  If not, see <https://www.gnu.org/licenses/>.\n\n");

      printf( "This seclone.exe is version %s.\n", &VERSION[2]);
      printf( "Compiled on %s at %s.\n\n", __DATE__, __TIME__);
   }

   return 0;
}

