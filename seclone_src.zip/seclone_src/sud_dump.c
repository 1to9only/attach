/* sud_dump.c - dump sudoku grid and clues
seclone.exe: sudoku explainer clone, singles only, solver, generator.
Copyright (C) 2018, 1to9only, <http://forum.enjoysudoku.com>.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
static char *dashes = "-------------------------------";
void dump_grid_clues( void)
{
   char s[20], ln[120] = { 0, };
   int i, k[Grdsize] = { 1, 1, 1, 1, 1, 1, 1, 1, 1 };
   for ( i=0; i<Sudsize; i++ )
      if ( k[i%Grdsize] < bcnt[clues[i]] )
         k[i%Grdsize] = bcnt[clues[i]];
   printf( "+%.*s+%.*s+%.*s+\n", k[0]+k[1]+k[2]+4, dashes, k[3]+k[4]+k[5]+4, dashes, k[6]+k[7]+k[8]+4, dashes);
   for ( i=0; i<Sudsize; i++ )
   {
      sprintf(s,"%s%-*d", i%Boxsize?" ":" | ", k[i%Grdsize], bnum[clues[i] | mbits[grid[i]]]);
      strcat(ln,s);
      if ( ( i%Grdsize) & (Grdsize-1) )
      {
         printf( "%s |\n", &ln[1]); ln[0] = 0;
         if ( i%(3*Grdsize) == (3*Grdsize-1) )
   printf( "+%.*s+%.*s+%.*s+\n", k[0]+k[1]+k[2]+4, dashes, k[3]+k[4]+k[5]+4, dashes, k[6]+k[7]+k[8]+4, dashes);
      }
   }
}

