/* er23_naked_single.c - SudoluExplainer clone
seclone.exe: sudoku explainer clone, singles only, solver, generator.
Copyright (C) 2018, 1to9only, <http://forum.enjoysudoku.com>.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
/**
 * Implementation of the Naked Single solving techniques.
 */
//blic class NakedSingle implements DirectHintProducer {
// /**
//  * Check if a cell has only one potential value, and accumulate
//  * corresponding hints
//  */
// public void getHints(Grid grid, HintsAccumulator accu) throws InterruptedException {
//    Grid.Region[] parts = grid.getRegions(Grid.Row.class);
//    // Iterate on parts
//    for (Grid.Region part : parts) {
//       // Iterate on cells
//       for (int index = 0; index < 9; index++) {
//          Cell cell = part.getCell(index);
//          // Get the cell's potential values
//          BitSet potentialValues = cell.getPotentialValues();
//          if (potentialValues.cardinality() == 1) {
//             // One potential value -> solution found
//             int uniqueValue = potentialValues.nextSetBit(0);
//             accu.add(new NakedSingleHint(this, null, cell, uniqueValue));
//          }
//       }
//    }
// }
// public double getDifficulty() {
//    return 2.3;
// }

int er23_naked_single( void)
{
   for (int row=0; row<9; row++ )
   {
      for (int index=0; index<9; index++ )
      {
         int cell = sudrow[ row][ index];
         if ( bcnt[ clues[ cell]] == 1 )        // naked single
         {
            int number = bnum[ clues[ cell]];

               grid[ cell] = number;            // set clue
               clues[ cell] = 0;                // clear clues

               for (int k=1; k<21; k++ )        // clear peers
               {
                  clues[ peer[ cell][ k]] &= ~mbits[ number];
               }
               if ( verbose > 0 ) {
               printf( "2.3, naked single: r%dc%d: %d\n", getrow[cell]+1, getcol[cell]+1, number);
               }
               placed = 1;
               return 23;

         }
      }
   }

   return 0;
}

