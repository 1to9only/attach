/* sud_solve.c - sudoku (SudokuExplainer clone) solver
seclone.exe: sudoku explainer clone, singles only, solver, generator.
Copyright (C) 2018, 1to9only, <http://forum.enjoysudoku.com>.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
#include "er10_hidden_single.c"
#include "er17_direct_pointing.c"
#include "er20_direct_hidden_pair.c"
#include "er23_naked_single.c"
#include "er25_direct_hidden_triplet.c"

void solve( void)
{
   int er = 0;

   do
   {
      er = placed = 0;

      if ( er == 0 ) { er = er10_hidden_single(); }
      if ( er == 0 ) { er = er17_direct_pointing(); }
      if ( er == 0 ) { er = er20_direct_hidden_pair(); }
      if ( er == 0 ) { er = er23_naked_single(); }
      if ( er == 0 ) { er = er25_direct_hidden_triplet(); }

      if ( er != 0 )
      {
         if ( er > rating ) { rating = er; }
         if ( pearl == 0 )
         {
            if ( diamond == 0 ) { diamond = rating; }
            if ( placed == 1 ) { pearl = rating; }
         }
      }
      if ( er != 0 && verbose == 2 ) { dump_grid_clues(); }
   } while ( er != 0 );

   // check if solved!
   for (int i=0; i<Sudsize; i++ ) { if ( grid[i] == 0 ) { rating = 0; break; } }
}

