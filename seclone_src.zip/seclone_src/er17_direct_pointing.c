// Locking(true)
// DirectLockingHint.java
// public Locking(boolean isDirectMode) {
//    this.isDirectMode = isDirectMode;
// }
// public void getHints(Grid grid, HintsAccumulator accu) throws InterruptedException {
//    getHints(grid, Grid.Block.class, Grid.Column.class, accu);
//    getHints(grid, Grid.Block.class, Grid.Row.class, accu);
//    getHints(grid, Grid.Column.class, Grid.Block.class, accu);
//    getHints(grid, Grid.Row.class, Grid.Block.class, accu);
// }
// public double getDifficulty() {
//    if (regions[0] instanceof Grid.Block)
//       return 1.7; // Pointing
//    else
//       return 1.9; // Claiming
// }

int er17_direct_pointing( void)
{

   return 0;
}

