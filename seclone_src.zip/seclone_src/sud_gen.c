/* sud_gen.c - sudoku generator
seclone.exe: sudoku explainer clone, singles only, solver, generator.
Copyright (C) 2018, 1to9only, <http://forum.enjoysudoku.com>.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
#include <time.h>

int gen_grid [ Sudsize] = { 0, };    // sudoku grid, numbers=1-9, 0=empty
int gen_clues[ Sudsize] = { 0, };    // bitwise clues, 0x0001=1, 0x0100=9, 0x01FF=full house

void generate( void)
{
   int minclues = 20 * Sudsize / 100;     // 20%
   int maxclues = 40 * Sudsize / 100;     // 40%
   int numclues = maxclues + 1;

   srand( time( NULL));                   // randomize

   // generate a sudoku

   int generating = True;
   while ( generating == True )
   {
      // if maxclues reached
      if ( numclues > maxclues )
      {
         // clear grid
         for (int i=0; i<Sudsize; i++ )
         {
            gen_grid[ i] = 0;
            gen_clues[ i] = AllBits;
         }
         numclues = 0;
      }

      // add a clue

      int addingclue = True;
      while ( addingclue == True )
      {
         int c = rand() % 81;             // random cell, 0-80

         if ( gen_grid[ c] == 0 )         // cell is empty?
         {
            int n = rand() % 9 + 1;       // random number, 1-9

            if ( gen_clues[ c] & mbits[ n] )    // number is a candidate?
            {
               gen_grid[ c] = n;          // set clue
               gen_clues[ c] = 0;         // clear clue
               for (int k=1; k<21; k++ )  // clear peers
               {
                  gen_clues[ peer[ c][ k]] &= ~mbits[ n];
               }
               numclues++;

               addingclue = False;
            }
         }
      }
      fprintf( stderr, "%d\x0d", numclues);
      fflush( stderr);

      // if have minclues
      if ( numclues > minclues )
      {
         // attempt solving
         for (int i=0; i<Sudsize; i++ )
         {
            grid[ i] = gen_grid[ i];
            clues[ i] = gen_clues[ i];
         }
         rating = 0;
         pearl = 0;
         diamond = 0;
         solve();

         if ( rating != 0 )               // success
         {
            generating = False;
         }
      }
   }

   for (int i=0; i<Sudsize; i++ ) {int n = gen_grid[ i]; printf( "%c", (n==0)?'.':'0'+n); } printf( "\n");

   printf( "ED=%d.%c/",   rating/10,  '0'+rating%10);
   printf(    "%d.%c/",    pearl/10,   '0'+pearl%10);
   printf(    "%d.%c\n", diamond/10, '0'+diamond%10);
}

