/* er10_hidden_single.c - SudokuExplainer clone
seclone.exe: sudoku explainer clone, singles only, solver, generator.
Copyright (C) 2018, 1to9only, <http://forum.enjoysudoku.com>.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
/**
 * Implementation of the Hidden Single solving technique.
 */
//blic class HiddenSingle implements DirectHintProducer {
// public void getHints(Grid grid, HintsAccumulator accu) throws InterruptedException {
//    // First alone cells (last empty cell in a region)
//    getHints(grid, Grid.Block.class, accu, true);
//    getHints(grid, Grid.Column.class, accu, true);
//    getHints(grid, Grid.Row.class, accu, true);
//    // Then hidden cells
//    getHints(grid, Grid.Block.class, accu, false);
//    getHints(grid, Grid.Column.class, accu, false);
//    getHints(grid, Grid.Row.class, accu, false);
// }
// /**
//  * For each parts of the given type, check if a value has only one
//  * possible potential position.
//  * @param regionType the type of the parts to check
//  */
// private <T extends Grid.Region> void getHints(Grid grid, Class<T> regionType,
//       HintsAccumulator accu, boolean aloneOnly) throws InterruptedException {
//    Grid.Region[] regions = grid.getRegions(regionType);
//    // Iterate on parts
//    for (Grid.Region region : regions) {
//       // Iterate on values
//       for (int value = 1; value <= 9; value++) {
//          // Get value's potential position
//          BitSet potentialIndexes = region.getPotentialPositions(value);
//          if (potentialIndexes.cardinality() == 1) {
//             // One potential position -> solution found
//             int uniqueIndex = potentialIndexes.nextSetBit(0);
//             Cell cell = region.getCell(uniqueIndex);
//             boolean isAlone = region.getEmptyCellCount() == 1;
//             if (isAlone == aloneOnly)
//                accu.add(new HiddenSingleHint(this, region, cell, value, isAlone));
//          }
//       }
//    }
// }
// public double getDifficulty() {
//    if (isAlone)
//       return 1.0;
//    else if (getRegion() instanceof Grid.Block)
//       return 1.2;
//    else
//       return 1.5;
// }

int er10_hidden_single( void)
{
   // First alone cells (last empty cell in a region)

   for (int block=0; block<9; block++ )
   {
      for (int number=1; number<=9; number++ )
      {
         int numbermask = 0;
         int emptycellcount = 0;
         for (int index=0; index<9; index++ )
         {
            if ( clues[ sudbox[ block][ index]] & mbits[ number] )
            {
               numbermask |= mbits[ index+1];
            }
            if ( grid[ sudbox[ block][ index]] == 0 )
            {
               emptycellcount++;
            }
         }
         if ( bcnt[ numbermask] == 1 )          // hidden single
         {
            int cell = sudbox[ block][ bnum[ numbermask]-1];
            if ( emptycellcount == 1 )
            {
               grid[ cell] = number;            // set clue
               clues[ cell] = 0;                // clear clues

               for (int k=1; k<21; k++ )        // clear peers
               {
                  clues[ peer[ cell][ k]] &= ~mbits[ number];
               }
               if ( verbose > 0 ) {
               printf( "1.0, hidden single: r%dc%d: %d in block\n", getrow[cell]+1, getcol[cell]+1, number);
               }
               placed = 1;
               return 10;
            }
         }
      }
   }
   for (int column=0; column<9; column++ )
   {
      for (int number=1; number<=9; number++ )
      {
         int numbermask = 0;
         int emptycellcount = 0;
         for (int index=0; index<9; index++ )
         {
            if ( clues[ sudcol[ column][ index]] & mbits[ number] )
            {
               numbermask |= mbits[ index+1];
            }
            if ( grid[ sudcol[ column][ index]] == 0 )
            {
               emptycellcount++;
            }
         }
         if ( bcnt[ numbermask] == 1 )          // hidden single
         {
            int cell = sudcol[ column][ bnum[ numbermask]-1];
            if ( emptycellcount == 1 )
            {
               grid[ cell] = number;            // set clue
               clues[ cell] = 0;                // clear clues

               for (int k=1; k<21; k++ )        // clear peers
               {
                  clues[ peer[ cell][ k]] &= ~mbits[ number];
               }
               if ( verbose > 0 ) {
               printf( "1.0, hidden single: r%dc%d: %d in column\n", getrow[cell]+1, getcol[cell]+1, number);
               }
               placed = 1;
               return 10;
            }
         }
      }
   }
   for (int row=0; row<9; row++ )
   {
      for (int number=1; number<=9; number++ )
      {
         int numbermask = 0;
         int emptycellcount = 0;
         for (int index=0; index<9; index++ )
         {
            if ( clues[ sudrow[ row][ index]] & mbits[ number] )
            {
               numbermask |= mbits[ index+1];
            }
            if ( grid[ sudrow[ row][ index]] == 0 )
            {
               emptycellcount++;
            }
         }
         if ( bcnt[ numbermask] == 1 )          // hidden single
         {
            int cell = sudrow[ row][ bnum[ numbermask]-1];
            if ( emptycellcount == 1 )
            {
               grid[ cell] = number;            // set clue
               clues[ cell] = 0;                // clear clues

               for (int k=1; k<21; k++ )        // clear peers
               {
                  clues[ peer[ cell][ k]] &= ~mbits[ number];
               }
               if ( verbose > 0 ) {
               printf( "1.0, hidden single: r%dc%d: %d in row\n", getrow[cell]+1, getcol[cell]+1, number);
               }
               placed = 1;
               return 10;
            }
         }
      }
   }

   // Then hidden cells

   for (int block=0; block<9; block++ )
   {
      for (int number=1; number<=9; number++ )
      {
         int numbermask = 0;
         for (int index=0; index<9; index++ )
         {
            if ( clues[ sudbox[ block][ index]] & mbits[ number] )
            {
               numbermask |= mbits[ index+1];
            }
         }
         if ( bcnt[ numbermask] == 1 )          // hidden single
         {
            int cell = sudbox[ block][ bnum[ numbermask]-1];
            {
               grid[ cell] = number;            // set clue
               clues[ cell] = 0;                // clear clues

               for (int k=1; k<21; k++ )        // clear peers
               {
                  clues[ peer[ cell][ k]] &= ~mbits[ number];
               }
               if ( verbose > 0 ) {
               printf( "1.2, hidden single: r%dc%d: %d in block\n", getrow[cell]+1, getcol[cell]+1, number);
               }
               placed = 1;
               return 12;
            }
         }
      }
   }
   for (int column=0; column<9; column++ )
   {
      for (int number=1; number<=9; number++ )
      {
         int numbermask = 0;
         for (int index=0; index<9; index++ )
         {
            if ( clues[ sudcol[ column][ index]] & mbits[ number] )
            {
               numbermask |= mbits[ index+1];
            }
         }
         if ( bcnt[ numbermask] == 1 )          // hidden single
         {
            int cell = sudcol[ column][ bnum[ numbermask]-1];
            {
               grid[ cell] = number;            // set clue
               clues[ cell] = 0;                // clear clues

               for (int k=1; k<21; k++ )        // clear peers
               {
                  clues[ peer[ cell][ k]] &= ~mbits[ number];
               }
               if ( verbose > 0 ) {
               printf( "1.5, hidden single: r%dc%d: %d in column\n", getrow[cell]+1, getcol[cell]+1, number);
               }
               placed = 1;
               return 15;
            }
         }
      }
   }
   for (int row=0; row<9; row++ )
   {
      for (int number=1; number<=9; number++ )
      {
         int numbermask = 0;
         for (int index=0; index<9; index++ )
         {
            if ( clues[ sudrow[ row][ index]] & mbits[ number] )
            {
               numbermask |= mbits[ index+1];
            }
         }
         if ( bcnt[ numbermask] == 1 )          // hidden single
         {
            int cell = sudrow[ row][ bnum[ numbermask]-1];
            {
               grid[ cell] = number;            // set clue
               clues[ cell] = 0;                // clear clues

               for (int k=1; k<21; k++ )        // clear peers
               {
                  clues[ peer[ cell][ k]] &= ~mbits[ number];
               }
               if ( verbose > 0 ) {
               printf( "1.5, hidden single: r%dc%d: %d in row\n", getrow[cell]+1, getcol[cell]+1, number);
               }
               placed = 1;
               return 15;
            }
         }
      }
   }

   return 0;
}

