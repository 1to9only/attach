// HiddenSet(3, true)
// public HiddenSet(int degree, boolean isDirect) {
//    assert degree > 1 && degree <= 4;
//    this.degree = degree;
//    this.isDirect = isDirect;
// }
// public void getHints(Grid grid, HintsAccumulator accu) throws InterruptedException {
//    getHints(grid, Grid.Block.class, accu);
//    getHints(grid, Grid.Column.class, accu);
//    getHints(grid, Grid.Row.class, accu);
// }
// DirectHiddenSetHint.java
// public double getDifficulty() {
//    int degree = values.length;
//    if (degree == 2)
//       return 2.0;
//    else if (degree == 3)
//       return 2.5;
//    else
//       return 4.3;
// }

int er25_direct_hidden_triplet( void)
{

   return 0;
}

