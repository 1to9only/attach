/* stormsolve.c */
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <io.h>

int __cdecl storm_init( void);
char* __cdecl storm_solve( char *psudoku);
#pragma comment( lib, "StormDoku")

int main( int argc, char *argv[])
{
   char *psudoku = (char*)0;
   char *psolved = (char*)0;
   char *pmethods = (char*)0;
   char buffer[ 100] = { 0, };
   struct _stat st = { 0, };
   int rc = 0, len = 0, f = 0;

   if ( argc == 2 )
   {
      if ( strlen( argv[1]) == 81 )          // is sudoku line
      {
         psudoku = argv[1];
      }
      else                                   // is sudoku file
      {
         rc = _stat( argv[1], &st);
         len = st.st_size;
         if ( rc == 0 && len >= 81 )
         {
            f = _open( argv[1], _O_RDONLY|_O_BINARY);
            if ( f != -1 )
            {
               rc = _read( f, buffer, 81);   // read 81 bytes only
               rc = close( f);
               buffer[ 81] = 0;              // null terminate after 81 chars
               psudoku = buffer;
            }
         }
         else
         {
            printf( "file '%s' not found!\n", argv[1]);
            exit( 1);
         }
      }
   }

   if ( psudoku != (char*)0 )
   {
      rc = storm_init();
      printf( "%s\n", psudoku);
      psolved = storm_solve( psudoku);
      printf( "%s\n", psolved);
      printf( "HN BHN XHN HBBNB SKESJSSW TTMT SLLHHHH IXBSTT AATADATF\n");
      printf( "SS LPP WTT QAAQA MYRWEMMW RRWR W1W1234 WYAURR LHRLDDRI\n");
      pmethods = (char*)storm_methods( "                                                                                ");
      printf( "%s\n", pmethods);
   }
   else
   {
      printf( "nothing to solve!\n");
   }

   return 0;
}

