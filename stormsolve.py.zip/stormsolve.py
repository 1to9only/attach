#! /usr/bin/python
# stormsolve.py
import sys, os, optparse
from ctypes import *

def main():
   parser = optparse.OptionParser()
   argc, argv = parser.parse_args()

   sudoku = ''

   if len( argv) == 1:
     if len( argv[ 0]) == 81:                   # a sudoku string as argument
        sudoku = argv[ 0]                       # sudoku from argument
     else:                                      # assume a sudoku filename
        isfile = os.path.isfile( argv[ 0])
        if not isfile:
           print( 'file "%s" not found!' % argv[ 0])
           sys.exit( 1)
        f = open( argv[ 0], 'r')
        sudoku = f.read( 81)
        sudoku = sudoku.replace( '\x0a', '')
        sudoku = sudoku.replace( '\x0d', '')
        f.close()
        if len( sudoku) < 81:
           print( 'line: "' + sudoku + '", is too short, length: ' + str( len( sudoku)))
           sys.exit( 2)

   if sudoku != '':
      print( sudoku)
      psudoku = sudoku.encode( 'ascii')
      stormdll = cdll.LoadLibrary( "StormDoku")
      rc = stormdll.storm_init()
      psolved = stormdll.storm_solve( psudoku)
      solved = psudoku.decode( 'utf-8')
      print( solved)

      methods ='                                                                                '
      pmethods = methods.encode( 'ascii')
      ptechniques = stormdll.storm_methods( pmethods)
      techniques = pmethods.decode( 'utf-8')
      print( 'HN BHN XHN HBBNB SKESJSSW TTMT SLLHHHH IXBSTT AATADATF')
      print( 'SS LPP WTT QAAQA MYRWEMMW RRWR W1W1234 WYAURR LHRLDDRI')
      print( techniques)

   else:
      print( 'nothing to solve!')

   return 0

if __name__ == '__main__':
   sys.exit( main())

